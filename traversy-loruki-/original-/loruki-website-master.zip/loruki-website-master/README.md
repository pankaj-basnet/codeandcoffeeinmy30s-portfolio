# Lokuri Website

> Fake cloud hosting website used in this [YouTube tutorial](https://www.youtube.com/watch?v=p0bGHP-PXD4)

> Fake cloud hosting website [Live Preview](https://zen-carson-c10c9f.netlify.app)
